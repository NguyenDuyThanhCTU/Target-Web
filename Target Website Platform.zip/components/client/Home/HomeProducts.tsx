import React from "react";

const HomeProducts = () => {
  return <div className="h-[50vh] bg-white">DisplayProduct</div>;
};

export default HomeProducts;
